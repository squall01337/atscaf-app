// 🔁 Version complète avec tableau + upload + boutons de soumission
import { useState, useRef } from "react";

const colonnes = [
  "H", "F", "Sports Loisir", "Bien-être Prof.", "Bien-être Salle", "Chpt CORPO",
  "+ de 15 licences", "- de 15 licences", "CNIF Avant 1/4", "CNIF 1/4", "CNIF 1/2 et finale",
  "Trophée 5", "Trophée 6 à 10", "Trophée >10", "Organisateur", "Participant",
  "Manif except.", "Equipes suppl.", "Compét (maxi 3)", "Activ nouv.", "Ecole sportive", "Activ.virtuelles"
];

const lignesInitiales = [
  { nom: "Manifestation Nationale", colonnes: Object.fromEntries(colonnes.map(c => [c, c === "Organisateur" ? 0 : null])) },
  { nom: "Coupe Régionale", colonnes: Object.fromEntries(colonnes.map(c => [c, ["Organisateur", "Participant"].includes(c) ? false : null])) },
  { nom: "Hand Ball", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Volley Ball Masculin", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Volley Ball Féminin", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Basket Ball Masculin", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Basket Ball Féminin", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Squash", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Bowling", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Pelote Basque", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Equitation", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Parachute-Parapente", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Golf", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Tir", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Tennis Masculin", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Tennis Féminin", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Tennis Table", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Judo", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Karaté", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Ski", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Escalade", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "VTT", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Cyclisme", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Triathlon", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Pétanque Masculine", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Pétanque Féminine", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Badminton", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Sports Nautiques", colonnes: Object.fromEntries(colonnes.map(c => [c, null])), categorie: true },
  { nom: "1-  Voile", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "2- Natation", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "3- Plongée", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "4- Canoé / kayak", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Athlétisme", colonnes: Object.fromEntries(colonnes.map(c => [c, null])), categorie: true },
  { nom: "1- Course à pied", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Karting", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Billard", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Musculation", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Tir à l'arc", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Bien être", colonnes: Object.fromEntries(colonnes.map(c => [c, null])), categorie: true },
  { nom: "NATURE", colonnes: Object.fromEntries(colonnes.map(c => [c, null])), categorie: true },
  { nom: "", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])), editable: true },
  { nom: "", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])), editable: true },
  { nom: "AQUATIQUE", colonnes: Object.fromEntries(colonnes.map(c => [c, null])), categorie: true },
  { nom: "", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])), editable: true },
  { nom: "", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])), editable: true },
  { nom: "GYMNIQUE", colonnes: Object.fromEntries(colonnes.map(c => [c, null])), categorie: true },
  { nom: "", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])), editable: true },
  { nom: "", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])), editable: true },
  { nom: "", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])), editable: true },
  { nom: "", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])), editable: true },
  { nom: "", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])), editable: true },
  { nom: "Autres activités", colonnes: Object.fromEntries(colonnes.map(c => [c, null])), categorie: true },
  { nom: "Escrime", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Paddle", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Roller", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Raquettes", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Echecs", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) },
  { nom: "Autres", colonnes: Object.fromEntries(colonnes.map(c => [c, ["H", "F"].includes(c) ? 0 : false])) }
];

export default function FormulaireSport() {
  const [data, setData] = useState(lignesInitiales);
  const [fichiers, setFichiers] = useState([]);
  const [fichierTemp, setFichierTemp] = useState(null);
  const [descriptionTemp, setDescriptionTemp] = useState("");
  const [etatFormulaire, setEtatFormulaire] = useState("brouillon");
  const [showModal, setShowModal] = useState(false);
  const fileInputRef = useRef();

  const toggleCheckbox = (i, col) => {
    const copy = [...data];
    copy[i].colonnes[col] = !copy[i].colonnes[col];
    setData(copy);
  };

  const updateNumber = (i, col, value) => {
    const copy = [...data];
    copy[i].colonnes[col] = value;
    setData(copy);
  };

  const [lignesActives, setLignesActives] = useState([]);

  const isDisabled = (row, col, i) => {
  if (row.categorie) return true;
  if (!lignesActives.includes(i)) return true;
  if (row.nom === "Manifestation Nationale") return col !== "Organisateur";
  if (row.nom === "Coupe Régionale") return !["Organisateur", "Participant"].includes(col);
  if (["Organisateur", "Participant"].includes(col)) return true;

  // 👉 Désactive "Bien-être Prof." et "Bien-être Salle" sauf si ligne editable
  if (
    ["Bien-être Prof.", "Bien-être Salle"].includes(col) &&
    !row.editable
  ) {
    return true;
  }

  return false;
};

  const calculerPoints = (row, i) => {
  if (!lignesActives.includes(i)) return 0; // 🔒 Ligne désactivée => total = 0

  let pts = 0;

  if (row.nom === "Manifestation Nationale") {
    pts += Math.min(row.colonnes["Organisateur"] || 0, 3) * 15;
  } else if (row.nom === "Coupe Régionale") {
    if (row.colonnes["Organisateur"]) pts += 15;
    if (row.colonnes["Participant"]) pts += 2;
  } else {
    if (row.colonnes["Sports Loisir"]) pts += 1;
    if (row.colonnes["+ de 15 licences"]) pts += 5;
    if (row.colonnes["- de 15 licences"]) pts += 2;
    if (row.colonnes["CNIF Avant 1/4"]) pts += 1;
    if (row.colonnes["CNIF 1/4"]) pts += 3;
    if (row.colonnes["CNIF 1/2 et finale"]) pts += 5;
    if (row.colonnes["Trophée 5"]) pts += 1;
    if (row.colonnes["Trophée 6 à 10"]) pts += 3;
    if (row.colonnes["Trophée >10"]) pts += 5;
  }

  if (row.colonnes["Manif except."]) pts += 10;

  const eq = parseInt(row.colonnes["Equipes suppl."]) || 0;
  pts += Math.min(eq, 3);

  return pts;
};

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFichierTemp(file);
      setShowModal(true);
    }
  };

  const ajouterFichier = () => {
    const now = new Date();
    setFichiers(prev => [
      ...prev,
      {
        nom: fichierTemp.name,
        taille: fichierTemp.size,
        date: now.toLocaleString(),
        description: descriptionTemp
      }
    ]);
    setFichierTemp(null);
    setDescriptionTemp("");
    setShowModal(false);
  };

  const supprimerFichier = (index) => {
    setFichiers(prev => prev.filter((_, i) => i !== index));
  };

  const handleSoumission = (statut) => {
    setEtatFormulaire(statut);
    alert(
      statut === "soumis"
        ? "Formulaire envoyé définitivement. Vous ne pourrez plus le modifier."
        : "Brouillon sauvegardé. Vous pourrez revenir dessus plus tard."
    );
  };

  return (
    <div className="p-6 max-w-[1850px] mx-auto">
      <h1 className="text-2xl font-semibold mb-6 text-center text-gray-800">Formulaire Subvention Sport</h1>

      {/* ✅ Tableau de subvention */}
      <div className="overflow-x-auto overflow-y-auto max-h-[600px] bg-white border border-gray-300 rounded shadow-md">
        <table className="w-full text-sm text-gray-800 border-separate border-spacing-0">
          <thead className="sticky top-0 z-20 bg-white text-[13px] text-center border border-gray-400 shadow-md">
  <tr>
    <th rowSpan={2} className="border border-gray-400 w-[160px]">Discipline</th>
    <th colSpan={2} className="border border-gray-400">Sportifs</th>
    <th rowSpan={2} className="border border-gray-400">Sports Loisir</th>
    <th colSpan={2} className="border border-gray-400">Bien-être</th>
    <th rowSpan={2} className="border border-gray-400">Chpt CORPO</th>
    <th rowSpan={2} className="border border-gray-400">+15 licences</th>
    <th rowSpan={2} className="border border-gray-400">-15 licences</th>
    <th colSpan={3} className="border border-gray-400">CNIF</th>
    <th colSpan={3} className="border border-gray-400">Trophées</th>
    <th rowSpan={2} className="border border-gray-400">Organisateur</th>
    <th rowSpan={2} className="border border-gray-400">Participant</th>
    <th rowSpan={2} className="border border-gray-400">Manif except.</th>
    <th rowSpan={2} className="border border-gray-400">Équipes sup. (maxi 3)</th>
    <th rowSpan={2} className="border border-gray-400">Compét (maxi 3)</th>
    <th rowSpan={2} className="border border-gray-400">Activ nouv.</th>
    <th rowSpan={2} className="border border-gray-400">Ecole sportive</th>
    <th rowSpan={2} className="border border-gray-400">Activ.virtuelles</th>
    <th rowSpan={2} className="border border-gray-400">Total</th>
  </tr>
  <tr>
    <th className="border border-gray-400">H</th>
    <th className="border border-gray-400">F</th>
    <th className="border border-gray-400">Prof.</th>
    <th className="border border-gray-400">Salle</th>
    <th className="border border-gray-400">Avant 1/4</th>
    <th className="border border-gray-400">1/4</th>
    <th className="border border-gray-400">1/2 et finale</th>
    <th className="border border-gray-400">5</th>
    <th className="border border-gray-400">6 à 10</th>
    <th className="border border-gray-400">&gt;10</th>
  </tr>
</thead>
          <tbody>
  {data.map((row, i) => {
    const isActive = lignesActives.includes(i);
    const ligneClasses = row.categorie
      ? "bg-gray-300 text-gray-700"
      : isActive
      ? "bg-green-100"
      : "even:bg-white odd:bg-gray-50";

    return (
      <tr key={i} className={ligneClasses}>
        <td
          onClick={() => {
            if (!row.categorie) {
              setLignesActives((prev) =>
                prev.includes(i)
                  ? prev.filter((x) => x !== i)
                  : [...prev, i]
              );
            }
          }}
          className={`cursor-pointer font-medium sticky left-0 z-10 border ${
            row.categorie ? "bg-gray-300" : isActive ? "bg-green-100" : "bg-white hover:bg-gray-100"
          }`}
        >
          {row.categorie ? (
            <strong>{row.nom}</strong>
          ) : row.editable ? (
            <input
              type="text"
              value={row.nom}
              onChange={(e) => {
                const copy = [...data];
                copy[i].nom = e.target.value;
                setData(copy);
              }}
              className="w-full px-2 py-1 border text-sm"
              placeholder="Nom de la discipline"
            />
          ) : (
            row.nom
          )}
        </td>

        {colonnes.map((col, j) => (
          <td
            key={j}
            className={`border text-center ${isDisabled(row, col, i) ? "bg-gray-200" : ""}`}
          >
            {!isDisabled(row, col, i) ? (
              typeof row.colonnes[col] === "number" ? (
                <input
                  type="number"
                  min={0}
                  value={row.colonnes[col]}
                  onChange={(e) =>
                    updateNumber(i, col, parseInt(e.target.value) || 0)
                  }
                  className="w-14 text-xs border px-1 text-right"
                />
              ) : (
                <input
                  type="checkbox"
                  checked={row.colonnes[col] || false}
                  onChange={() => toggleCheckbox(i, col)}
                />
              )
            ) : null}
          </td>
        ))}

        <td className="border text-center font-bold text-gray-800">
          {!row.categorie ? calculerPoints(row, i) : ""}
        </td>
      </tr>
    );
  })}
</tbody>
        </table>
      </div>

      {/* ✅ Fichiers justificatifs */}
      <div className="mt-10">
        <h2 className="text-xl font-bold mb-2 text-gray-800">Pièces justificatives</h2>
        <p className="text-sm text-gray-600 mb-4">Téléversez vos fichiers (licences, factures…)</p>

        <div
          className="border-2 border-dashed border-gray-300 p-6 text-center rounded-xl cursor-pointer hover:border-gray-500"
          onClick={() => fileInputRef.current.click()}
        >
          <p className="text-gray-600">Cliquez ou glissez-déposez vos fichiers ici</p>
          <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" />
        </div>

        {fichiers.length > 0 && (
          <table className="mt-6 w-full text-sm border">
            <thead className="bg-gray-100">
              <tr>
                <th>Nom</th><th>Taille</th><th>Date</th><th>Description</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {fichiers.map((f, i) => (
                <tr key={i} className="even:bg-white odd:bg-gray-50">
                  <td>{f.nom}</td>
                  <td>{(f.taille / 1024).toFixed(1)} Ko</td>
                  <td>{f.date}</td>
                  <td>{f.description}</td>
                  <td className="text-center">
                    <button onClick={() => supprimerFichier(i)} className="bg-red-600 text-white px-2 py-1 rounded">Supprimer</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* ✅ Modal description */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
            <h3 className="text-lg font-semibold mb-3">Description du fichier</h3>
            <textarea
              value={descriptionTemp}
              onChange={(e) => setDescriptionTemp(e.target.value)}
              placeholder="Décrivez ce fichier..."
              className="w-full border rounded px-3 py-2 min-h-[100px]"
            />
            <div className="flex justify-end mt-4 gap-2">
              <button onClick={() => setShowModal(false)} className="bg-gray-200 px-4 py-2 rounded">Annuler</button>
              <button onClick={ajouterFichier} className="bg-blue-600 text-white px-4 py-2 rounded">Téléverser</button>
            </div>
          </div>
        </div>
      )}

      {/* ✅ Boutons de soumission */}
      <div className="mt-10 flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-sm text-gray-600">
          Statut actuel :
          <span className={`ml-2 font-semibold ${etatFormulaire === "soumis" ? "text-green-700" : "text-yellow-700"}`}>
            {etatFormulaire === "soumis" ? "Envoyé définitivement" : "Brouillon"}
          </span>
        </p>
        <div className="flex gap-4">
          <button onClick={() => handleSoumission("brouillon")} className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700">
            Enregistrer en brouillon
          </button>
          <button onClick={() => handleSoumission("soumis")} className="bg-blue-700 text-white px-4 py-2 rounded hover:bg-blue-800">
            Envoyer définitivement
          </button>
        </div>
      </div>
    </div>
  );
}